# safety_datasheet
Odoo Product Safety Datasheet

This module allows you to fill in the safety data sheets following the 16 points of the European Commission Regulation (EU) 2020/878 available here:
http://data.europa.eu/eli/reg/2020/878/oj

It is possible to print the SDS in the languages installed on the Odoo system


