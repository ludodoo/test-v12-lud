# -*- coding: utf-8 -*-

from . import sentences
from . import precautionary_statement
from . import pictogram
from . import hazard_class
from . import chemical_property
from . import hazard_statement
from . import chemical_substance
from . import regulation
from . import datasheet
from . import legend
from . import bibliography

