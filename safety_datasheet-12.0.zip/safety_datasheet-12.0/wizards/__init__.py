# -*- coding: utf-8 -*-

from . import select_lang